const Koa = require("koa");
const app = new Koa();
const main = (ctx) => {
    if (ctx.request.path == ("/koa")) {
        ctx.set({ 'Content-Type': 'text/html' });
        ctx.response.body = "<h1>Hello World</h1>";
        ctx.response.status = 400;
    } else {
        ctx.response.body = 'Hello World';
    }
};

app.use(main);
app.listen(8000, '127.0.0.1');
console.log('Node.js web server at port 8000 is running..')
